import api from './api';

export { api };
export default {};
