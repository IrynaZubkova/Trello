// src/common/interfaces/ICard.d.ts

export interface ICard {
  id: number;
  title: string;
}
